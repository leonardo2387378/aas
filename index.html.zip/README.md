# Quiz Interativo com Imagens e Música 🎮🎵

Este é um projeto de quiz HTML interativo com personalização visual por meio de imagens e trilhas sonoras via YouTube. Ideal para experiências imersivas e criativas!

## 🧩 Conteúdo

O projeto inclui 4 páginas de quiz:

- `quiz1.html`: com imagem personalizada e player do YouTube.
- `quiz2.html`: com nova imagem e outra trilha sonora.
- `quiz3.html`: nova imagem romântica + player fixo.
- `quiz4.html`: imagem e som final para encerrar o quiz.

As imagens estão integradas ao bloco de perguntas. O player de música aparece no canto inferior direito da tela.

## 📁 Estrutura de Arquivos

```
├── quiz1.html
├── quiz2.html
├── quiz3.html
├── quiz4.html
├── 517826598_1281029630053764_6809919902039031403_n.jpg
├── 518792983_2024779038334243_7336997583127954766_n.jpg
├── 520705600_1107638484558067_8243716262981514316_n.jpg
├── 519622069_1720896211876109_1530326511594339108_n.jpg
```

## 🚀 Como usar

1. Clone ou baixe este repositório.
2. Abra qualquer dos arquivos `quizX.html` em seu navegador.
3. Aproveite o quiz com música e visuais integrados.

```bash
git clone https://github.com/SEU_USUARIO/quiz-completo.git
cd quiz-completo
```

## ✨ Créditos

Imagens e trilhas sonoras utilizadas com fins educacionais/demonstrativos.
